.. uHand UNO documentation master file, created by
   sphinx-quickstart on Thu Jul 25 14:39:47 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :maxdepth: 2
   :caption: uHand UNO

   docs/1.try_it_out_hands_on.md
   docs/2.offline_knob_programming.md
   docs/3.app_control.md
   docs/4.secondary_development_preparation.md
   docs/5.secondary_development_course.md
   docs/6.ai_vision_game_course.md
   docs/7.wireless_glove_control_course.md
   docs/8.serial_communication_instruction.md
